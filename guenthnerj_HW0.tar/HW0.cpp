#include <iostream>
using namespace std;

int main() {
cout<< "Knock knock";
cout<< "\nWho's there?";
cout<< "\nBanana";
cout<< "\nBanana who?";
cout<< "\n\nKnock knock";
cout<< "\nWho's there?";
cout<< "\nBanana";
cout<< "\nBanana who?";
cout<< "\n\nKnock knock";
cout<< "\nWho's there?";
cout<< "\nBanana";
cout<< "\nBanana who?";
cout<< "\n\nKnock knock";
cout<< "\nWho's there?";
cout<< "\nOrange";
cout<< "\nOrange who?";
cout<< "\nOrange you glad I didn't say banana again?" << endl;
return 0;
}